from django.urls import path
from .views import download_view, convert_video_view

urlpatterns = [
    path('', download_view, name='download_view'),
    path('convert', convert_video_view, name='convert_video_view'),
]

