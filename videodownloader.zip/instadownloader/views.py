import os
import re
import subprocess
import json
import instaloader
from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.conf import settings

def get_video_info(video_file):
    command = [
        'ffprobe', '-v', 'error', '-show_format', '-show_streams', '-print_format', 'json', video_file
    ]
    result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    try:
        return json.loads(result.stdout)
    except json.JSONDecodeError:
        print(f"Error parsing JSON from ffprobe output:\n{result.stderr.decode('utf-8')}")
        return None

def display_available_qualities_and_extensions(video_info):
    video_streams = [stream for stream in video_info['streams'] if stream['codec_type'] == 'video']
    if not video_streams:
        print("No video streams found.")
        return None, None

    original_resolution = video_streams[0]['height']
    print(f"Original video resolution: {original_resolution}p")
    print("Available extensions: mp4, mkv")

    return original_resolution, ['mp4', 'mkv']

def download_instagram_video(url, output_dir):
    L = instaloader.Instaloader(download_videos=True, download_pictures=False, download_comments=False, save_metadata=False, post_metadata_txt_pattern='')

    match = re.search(r"instagram\.com/(reel|p)/([^/?#&]+)", url)
    if not match:
        print("Invalid URL")
        return None

    shortcode = match.group(2)
    L.dirname_pattern = output_dir

    try:
        post = instaloader.Post.from_shortcode(L.context, shortcode)
        if post.is_video:
            L.download_post(post, target=output_dir)
            print(f"Video downloaded successfully to {output_dir}")

            # Find the downloaded video file
            video_file = None
            for filename in os.listdir(output_dir):
                if filename.endswith('.mp4'):
                    video_file = os.path.join(output_dir, filename)
                    file_name = filename
                    break

            if video_file:
                video_info = get_video_info(video_file)
                if video_info:
                    original_resolution, available_extensions = display_available_qualities_and_extensions(video_info)

                    if original_resolution and available_extensions:
                        return {
                            'video_file': video_file,
                            'original_resolution': original_resolution,
                            'available_extensions': available_extensions,
                            'file_name': file_name
                        }
                    else:
                        print("No valid video information found.")
                else:
                    print("Failed to get video information.")
            else:
                print("Video file not found.")
        else:
            print("The provided URL does not contain a video.")
    except Exception as e:
        print(f"An error occurred: {e}")
    return None

def download_view(request):
    if request.method == 'POST':
        url = request.POST['url']
        output_dir = settings.MEDIA_ROOT
        os.makedirs(output_dir, exist_ok=True)
        video_info = download_instagram_video(url, output_dir)
        if video_info:
            return render(request, 'instadownloader/formats.html', video_info)
        else:
            return HttpResponse("Failed to download or process the video.")
    return render(request, 'instadownloader/index.html')

def convert_video_view(request):
    if request.method == 'POST':
        video_file = request.POST['video_file']
        quality = request.POST['quality']
        extension = request.POST['extension']
        file_name = request.POST['file_name']
        output_dir = settings.MEDIA_ROOT

        output_file = os.path.join(output_dir, f'{file_name}_{quality}.{extension}')
        ffmpeg_command = [
            'ffmpeg',
            '-i', video_file,
            '-vf', f'scale=-2:{quality}',  # Adjust the height while keeping the aspect ratio
            output_file
        ]
        subprocess.run(ffmpeg_command)
        os.remove(video_file)
        video_url = os.path.join(settings.MEDIA_URL, os.path.basename(output_file))
        return render(request, 'instadownloader/download.html', {'video_url': video_url})
    return redirect('instadownloader:download_view')
