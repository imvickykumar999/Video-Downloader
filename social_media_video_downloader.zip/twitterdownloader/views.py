import os
import yt_dlp
from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.conf import settings
from datetime import datetime

def index(request):
    if request.method == 'POST':
        url = request.POST['url']
        format = request.POST['format']
        success, message = download_twitter_video(url, format)
        if success:
            return render(request, 'twitterdownloader/download.html', {'video_url': message})
        else:
            return HttpResponse(message, status=500)
    return render(request, 'twitterdownloader/index.html')

def download_twitter_video(url, format='bestvideo+bestaudio/best'):
    try:
        output_dir = settings.MEDIA_ROOT
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
        
        ydl_opts = {
            'outtmpl': f'{output_dir}/{timestamp}.%(ext)s',  # Use timestamp as filename
            'format': format,
            'merge_output_format': 'mp4',  # Ensure the output is merged into a single mp4 file
        }
        
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            ydl.download([url])
        return True, os.path.join(settings.MEDIA_URL, f"{timestamp}.mp4")
    except yt_dlp.DownloadError as e:
        return False, f"Error downloading video: {e}"
