from django.apps import AppConfig

class InstaphotodownloaderConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'instaphotodownloader'
