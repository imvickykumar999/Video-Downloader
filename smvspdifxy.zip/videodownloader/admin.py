from django.contrib import admin
from .models import PageView

admin.site.register(PageView)
