from django.shortcuts import render
from django.conf import settings
import os

def home_view(request):
    video_folders = ['youtube', 'instagram', 'facebook', 'twitter']
    videos = {}
    
    for folder in video_folders:
        folder_path = os.path.join(settings.MEDIA_ROOT, folder)
        if os.path.exists(folder_path):
            videos[folder] = [
                (file, os.path.join(settings.MEDIA_URL, folder, file))
                for file in os.listdir(folder_path) if file.endswith(('.mp4', '.mkv', '.webm'))
            ]
    
    return render(request, 'home.html', {'videos': videos})
