from django.apps import AppConfig


class YoutubedownloaderConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'youtubedownloader'
